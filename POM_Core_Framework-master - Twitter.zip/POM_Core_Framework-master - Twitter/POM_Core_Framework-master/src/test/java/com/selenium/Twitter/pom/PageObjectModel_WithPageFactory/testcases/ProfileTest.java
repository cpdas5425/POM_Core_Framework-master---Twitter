package com.selenium.Twitter.pom.PageObjectModel_WithPageFactory.testcases;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import com.selenium.Twitter.pom.PageObjectModel_WithPageFactory.pages.LaunchPage;
import com.selenium.Twitter.pom.PageObjectModel_WithPageFactory.pages.LoginPage;
import com.selenium.Twitter.pom.PageObjectModel_WithPageFactory.pages.session.LandingPage;
import com.selenium.Twitter.pom.PageObjectModel_WithPageFactory.pages.session.ProfilePage;
import com.selenium.Twitter.pom.PageObjectModel_WithPageFactory.testcases.base.BaseTest;
import com.selenium.Twitter.pom.PageObjectModel_WithPageFactory.util.DataUtil;


public class ProfileTest extends BaseTest {
	public void user_clicks_on_login_button() throws Throwable {
		 //Click Profile
			 Thread.sleep(2000);
		 WebDriverWait wait = new WebDriverWait(driver,30);
		 WebElement Profile;
		 //Profile= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Profile')]"))); 
		 Profile= wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Profile')]"))); 
		 
		 driver.findElement(By.xpath("//span[contains(text(),'Profile')]")).click();
		 
		 WebElement EditProfile;
		 EditProfile= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Edit profile')]"))); 
		 EditProfile.click();
		 Thread.sleep(2000);
		//Upload image
		 JavascriptExecutor jse = (JavascriptExecutor) driver; 
		 jse.executeScript("arguments[0].setAttribute('style', arguments[1])", driver.findElement(By.xpath("/descendant::input[@type='file'][1]")), "0");
		 jse.executeScript("arguments[0].setAttribute('class', arguments[1])", driver.findElement(By.xpath("/descendant::input[@type='file'][1]/../../div[2]")), "a");
		 driver.findElement(By.xpath("//input[@type='file']")).sendKeys("C:\\Users\\cd250049\\Desktop\\Test Twitter\\TwitterAutomationSeleniumBDDCucumber-main\\TwitterAutomationSeleniumBDDCucumber-main\\resources\\TwitterDP2.JPG");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//span[contains(text(),'Apply')]")).click();
		 Thread.sleep(6000);
		 }
		
	@Test
		 public void user_enters_bio_on_profile_page() {
			 WebDriverWait wait = new WebDriverWait(driver,30);
		 //BIO
		 WebElement TextBio;
		 TextBio=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[4]/label[1]/div[1]/div[2]/div[1]/textarea[1]")));
		 TextBio.click();
		 TextBio.sendKeys(Keys.CONTROL+"A" + Keys.BACK_SPACE);
		 TextBio.sendKeys("Selenium Automation user");
		 }
		 
		 @Test
		 public void user_enters_Location_on_profile_page() {
		 //Location
			 WebDriverWait wait = new WebDriverWait(driver,30);
		 WebElement Location;
		 Location=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[5]/label[1]/div[1]/div[2]/div[1]/input[1]")));
		 Location.click();
		 Location.sendKeys(Keys.CONTROL+"A" + Keys.BACK_SPACE);
		 Location.sendKeys("Houston, Texas");
		 }
		 
		 @Test
		 public void user_enters_Website_on_profile_page() {
		//Website
			 WebDriverWait wait = new WebDriverWait(driver,30);
			 WebElement Website;
			 Website=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//body/div[@id='react-root']/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[6]/label[1]/div[1]/div[2]/div[1]/input[1]")));
			 Website.click();
			 Website.sendKeys(Keys.CONTROL+"A" + Keys.BACK_SPACE);
			 Website.sendKeys("https://twitter.com");
			 
			driver.findElement(By.xpath("//span[contains(text(),'Save')]")).click();
		 
		 }
		 @Test 
		 public void fetch_and_veify_user_details(DataTable userdata) throws InterruptedException {
			 List<List<String>> data = userdata.raw();
			 driver.navigate().refresh();
			 Thread.sleep(6000);
			 WebDriverWait wait = new WebDriverWait(driver,30);
			 WebElement UserBioelem;
			 UserBioelem=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[2]/main[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/span[1]")));
			// Fetch and Assert User details update is success
			 String UserBio = UserBioelem.getText();
			 System.out.println("UserBio ::"+ UserBio);
			 String UserLoc = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[2]/main[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[4]/div[1]/span[1]/span[1]/span[1]")).getText();
			 System.out.println("UserLoc ::"+ UserLoc);
			 String UserWebsite = driver.findElement(By.xpath("//body/div[@id='react-root']/div[1]/div[1]/div[2]/main[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[4]/div[1]/a[1]")).getText();
			 System.out.println("UserWebsite ::"+ UserWebsite);
			 Assert.assertEquals(data.get(1).get(0), UserBio);
			 Assert.assertEquals(data.get(1).get(1), UserLoc);
			 Assert.assertEquals(data.get(1).get(2), UserWebsite);
		 }
		 
	
	String testCaseName = "ProfileTest";
	@Test
	public void testProfile(){
		
		test=extent.startTest("Profile Test");
		if(!DataUtil.isTestExecutable(xls,testCaseName)) {
			test.log(LogStatus.SKIP,"Skipping the test as Runmode is N");
			throw new SkipException("Skipping the test as Runmode is  N");
			
		}
		test.log(LogStatus.INFO, "Starting Profile Test");
		init("Mozilla");
		LaunchPage launchPage = new LaunchPage(driver,test);
		PageFactory.initElements(driver,launchPage);
		
		LoginPage loginpage = launchPage.gotoLoginPage();
		loginpage.verifyTitle("Twitter login");
		Object page = loginpage.doLogin("cpdas5425@gmail.com","Teradata@1234");
		if(page instanceof LoginPage)
			Assert.fail("Login Failed");
		else if(page instanceof LandingPage)
			System.out.println("Logged in Successfully");
		LandingPage landingPage = (LandingPage)page;
		landingPage.getMenu().search();
		landingPage.verifyTitle("XXXX");
		
		ProfilePage profPage = landingPage.gotoProfilePage();
		profPage.verifyProfile();
		test.log(LogStatus.INFO,"Test Passed");
		profPage.takeScreenShot();
		//profPage.getMenu();
		//profPage.getMenu().logout();
		
	
	}
	
	@AfterMethod
	public void quit() {
		if(extent!=null) {
			extent.endTest(test);
			extent.flush();
		}
		
		if(driver!=null)
			driver.quit();
	}
	
	
	
	

}
