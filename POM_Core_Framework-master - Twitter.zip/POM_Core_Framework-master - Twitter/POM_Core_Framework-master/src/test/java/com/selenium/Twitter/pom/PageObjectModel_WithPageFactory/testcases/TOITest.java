package com.selenium.Twitter.pom.PageObjectModel_WithPageFactory.testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import com.selenium.Twitter.pom.PageObjectModel_WithPageFactory.pages.LaunchPage;
import com.selenium.Twitter.pom.PageObjectModel_WithPageFactory.pages.LoginPage;
import com.selenium.Twitter.pom.PageObjectModel_WithPageFactory.pages.session.LandingPage;
import com.selenium.Twitter.pom.PageObjectModel_WithPageFactory.pages.session.ProfilePage;
import com.selenium.Twitter.pom.PageObjectModel_WithPageFactory.testcases.base.BaseTest;
import com.selenium.Twitter.pom.PageObjectModel_WithPageFactory.util.DataUtil;

import cucumber.api.java.en.Then;
import stepDefinitions.print;




public class TOITest extends BaseTest {
	
	String testCaseName = "TOITest";
	@Test
	public void user_opens_TOI_Website(){
		
		test=extent.startTest("TOI Test");
		if(!DataUtil.isTestExecutable(xls,testCaseName)) {
			test.log(LogStatus.SKIP,"Skipping the test as Runmode is N");
			throw new SkipException("Skipping the test as Runmode is  N");
			 WebDriverWait wait = new WebDriverWait(driver,30);
			 
			 //TOI
			 WebElement SearchBox;
			 SearchBox=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//body/div[@id='react-root']/div[1]/div[1]/div[2]/main[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/div[1]/div[2]/input[1]")));
			 
			 SearchBox.sendKeys("The Times of India"+ Keys.ARROW_DOWN+Keys.ARROW_DOWN+Keys.ENTER);
			 driver.get('https://twitter.com/TOI/followers')



			 followers_link=driver.page_source  #follwer page 18at a time
			 TimesOfIndia=TweetsTimesOfIndia(followers_link,'html.parser')

			 output=open('twitter_follower_r.csv','a')
			 output.write('Name,Twitter_Handle,Location,Bio,Join_Date,Link'+'\n')
			 div = TimesOfIndia.find('div',{'class':'GridTimeline-items has-items'})
			 bref = div.findAll('a',{'class':'ProfileCard-bg js-nav'})
			 name_list=[]
			 lastHeight = driver.execute_script("return document.body.scrollHeight")

			 followers_link=driver.page_source  #follwer page 18at a time
			 TimesOfIndia=TweetsTimesOfIndia(followers_link,'html.parser')

			 followers_per_page = 18
			 followers_count = 15777


			 for _ in xrange(0, followers_count/followers_per_page + 1):
			         driver.execute_script("window.scrollTo(0, 7755000);")
			         time.sleep(2)
			         newHeight = driver.execute_script("return document.body.scrollHeight")
			         if newHeight == lastHeight:
			                 followers_link=driver.page_source  #follwer page 18at a time
			                 TimesOfIndia=TweetsTimesOfIndia(followers_link,'html.parser')
			                 div = TimesOfIndia.find('div',{'class':'GridTimeline-items has-items'})
			                 bref = div.findAll('a',{'class':'ProfileCard-bg js-nav'})
			                 for name in bref:
			                         name_list.append(name['href'])
			                 break
			         lastHeight = newHeight
			         followers_link=''

			 print len(name_list)

			 '''
			 for x in range(0,len(name_list)):
			         #print name['href']
			         #print name.text
			         driver.stop_client()
			         driver.get('https://twitter.com'+name_list[x])
			         page_source=driver.page_source
			         each_TimesOfIndia=TweetsTimesOfIndia(page_source,'html.parser')
			         profile=each_TimesOfIndia.find('div',{'class':'ProfileHeaderCard'})
			                             
			         try:
			                 name = profile.find('h1',{'class':'ProfileHeaderCard-name'}).find('a').text
			                 if name:
			                         output.write('"'+name.strip().encode('utf-8')+'"'+',')
			                 else:
			                         output.write(' '+',')
			         except Exception as e:
			                 output.write(' '+',')
			                 print 'Error in name:',e

			         try:
			                 handle=profile.find('h2',{'class':'ProfileHeaderCard-screenname u-inlineBlock u-dir'}).text
			                 if handle:
			                         output.write('"'+handle.strip().encode('utf-8')+'"'+',')
			                 else:
			                         output.write(' '+',')
			         except Exception as e:
			                 output.write(' '+',')
			                 print 'Error in handle:',e

			         try:
			                 location = profile.find('div',{'class':'ProfileHeaderCard-location'}).text
			                 if location:
			                         output.write('"'+location.strip().encode('utf-8')+'"'+',')
			                 else:
			                         output.write(' '+',')
			         except Exception as e:
			                 output.write(' '+',')
			                 print 'Error in location:',e

			         try:
			                 bio=profile.find('p',{'class':'ProfileHeaderCard-bio u-dir'}).text
			                 if bio:
			                         output.write('"'+bio.strip().encode('utf-8')+'"'+',')
			                 else:
			                         output.write(' '+',')
			         except Exception as e:
			                 output.write(' '+',')
			                 print 'Error in bio:',e
			                         
			         try:
			                 joinDate = profile.find('div',{'class':'ProfileHeaderCard-joinDate'}).text
			                 if joinDate:
			                         output.write('"'+joinDate.strip().encode('utf-8')+'"'+',')
			                 else:
			                         output.write(' '+',')
			         except Exception as e:
			                 output.write(' '+',')
			                 print 'Error in joindate:',e
			         
			         try:
			                 url =  [check.find('a') for check in profile.find('div',{'class':'ProfileHeaderCard-url'}).findAll('span')][1]
			                 if url:
			                         output.write('"'+url['href'].strip().encode('utf-8')+'"'+'\n')
			                 else:
			                         output.write(' '+'\n')
			         except Exception as e:
			                 output.write(' '+'\n')
			                 print 'Error in url:',e      


			         
			 output.close()
		}
		test.log(LogStatus.INFO, "Starting Profile Test");
		init("Mozilla");
		LaunchPage launchPage = new LaunchPage(driver,test);
		PageFactory.initElements(driver,launchPage);
		
		LoginPage loginpage = launchPage.gotoLoginPage();
		loginpage.verifyTitle("Twitter login");
		Object page = loginpage.doLogin("cpdas5425@gmail.com","Teradata@1234");
		if(page instanceof LoginPage)
			Assert.fail("Login Failed");
		else if(page instanceof LandingPage)
			System.out.println("Logged in Successfully");
		LandingPage landingPage = (LandingPage)page;
		landingPage.getMenu().search();
		landingPage.verifyTitle("XXXX");
		
		ProfilePage profPage = landingPage.gotoProfilePage();
		profPage.verifyProfile();
		test.log(LogStatus.INFO,"Test Passed");
		profPage.takeScreenShot();
		//profPage.getMenu();
		//profPage.getMenu().logout();
		
	
	}
	
	@AfterMethod
	public void quit() {
		if(extent!=null) {
			extent.endTest(test);
			extent.flush();
		}
		
		if(driver!=null)
			driver.quit();
	}
	
	
	
	

}
