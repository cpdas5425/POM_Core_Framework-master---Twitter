package com.selenium.Twitter.pom.PageObjectModel_WithPageFactory.util;

public class Constants {
	public static final String CHROME_DRIVER_EXE = "C:\\Selenium_Automation\\LibraryFiles\\chromedriver.exe";
	
	//Default username and Password
	public static final String DEFAULT_USERNAME = "cpdas5425@gmail.com";
	public static final String DEFAULT_PASSWORD = "Teradata@1234";
	
	//locators
	public static final String LOGIN_USERNAME ="//input[@name='session[username_or_email]']\"";
	public static final String PASSWORD ="//input[@name='session[password]']";
	public static final String PROFILEPAGE_LINK = "//*[@id='u_0_a']/div[1]/div[1]/div/a/span/span";
	public static final String NAVIGATION_LABEL = "//*[@id='userNavigationLabel']";
	public static final String SETTINGS_LINK = "//span[text()='Settings']";
	public static final String SECURITYANDLOGIN = "//*[@id=\"react-root\"]/div/div/div/main/div/div/div/div[1]/div[1]/div/form/div/div[3]/div/div";
	public static final String PASSWORD_CHANGE = "//*[@id='SettingsPage_Content']/div/div/div/div[3]/div[2]//button[@type='submit']";
	public static final String OLD_PASSWORD = "//*[@id='password_old']";
	public static final String NEW_PASSWORD = "//*[@id='password_new']";
	public static final String CONFIRM_CHANGE = "//*[@id='password_confirm']";
	public static final String SAVE_CHANGES = "//*[@class='submit uiButton uiButtonConfirm']";
	
	
	//TOI Page locators
	public static final String INPUT_SEARCHFRIENDS = "//*[@id='pagelet_timeline_medley_friends']/div[1]//input[@class='inputtext']";
	public static final String SEARCHFRIENDS_BUTTON = "//*[@id='pagelet_timeline_medley_friends']/div[1]//button[@type='submit' and @title='Search for your friends']";
	
	//Profile Page locators
	public static final String PHOTOS_TAB = "//span[contains(text(),'Profile')]";
	public static final String FRIENDS_TAB ="//div[@id='fbTimelineHeadline']//a[@data-tab-key='friends']";
	
	
	//URLs
	public static final String HOMEPAGE_URL = "https://www.Twitter.com/";
	
	//Paths
	public static final String REPORTS_PATH = "C:\\Users\\cd250049\\Desktop\\Desktop 2020\\Assignments\\WorkOut\\POM_Core_Framework-master - Twitter\\POM_Core_Framework-master\\reports\\screenshots";
	public static final String DATA_XLS_PATH = System.getProperty("user.dir")+"\\data\\Data.xlsx";

	public static final String TESTDATA_SHEET = "TestData";

	public static final Object RUNMODE_COL = "Runmode";

	public static final String KILL_SESSION = "//input[@value='kill_sessions']";

	public static final String CONTINUE_PASSWORD_CHANGE_BUTTON = "//button[text()='Continue']";

	public static final String TESTCASES_SHEET = "TestCases";


	
	
	
	

	

	
	

	

	

	

	

	

	

	
	
	
	
}
